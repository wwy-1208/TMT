import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from peft import LoraConfig, TaskType, get_peft_model
from models.GPT2_arch import AccustumGPT2Model  # 假设 AccustumGPT2Model 在这里
from transformers import GPT2Tokenizer

# --- 导入 GNN 依赖 ---

from torch_geometric.nn import GCNConv
from torch_geometric.data import Data


class GNN(torch.nn.Module):
    def __init__(self, in_channels, out_channels):
        super(GNN, self).__init__()
        self.conv1 = GCNConv(in_channels, 32)
        self.conv2 = GCNConv(32, out_channels)

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = F.relu(self.conv1(x, edge_index))
        x = self.conv2(x, edge_index)
        return x


class Prompt(nn.Module):
    def __init__(self, length=2, embed_dim=768, embedding_key='mean', prompt_init='uniform', prompt_pool=False,
                 prompt_key=False, pool_size=30, top_k=4, batchwise_prompt=False, prompt_key_init='uniform', wte=None):
        super().__init__()

        self.length = length
        self.embed_dim = embed_dim
        self.prompt_pool = prompt_pool
        self.embedding_key = embedding_key
        self.prompt_init = prompt_init
        self.prompt_key = prompt_key
        self.prompt_key_init = prompt_key_init
        self.pool_size = pool_size
        self.top_k = top_k
        self.batchwise_prompt = batchwise_prompt
        self.wte = wte
        self.linear = nn.Linear(768, 512)

        if self.prompt_pool:
            prompt_pool_shape = (pool_size, length, embed_dim)
            if prompt_init == 'zero':
                self.prompt_pool_vecs = nn.Parameter(torch.zeros(prompt_pool_shape))
            elif prompt_init == 'uniform':
                self.prompt_pool_vecs = nn.Parameter(torch.randn(prompt_pool_shape))
                nn.init.uniform_(self.prompt_pool_vecs, -1, 1)

        # if using learnable prompt keys
        if prompt_key:
            key_shape = (pool_size, embed_dim)
            if prompt_key_init == 'zero':
                self.prompt_key_vecs = nn.Parameter(torch.zeros(key_shape), requires_grad=False)
            elif prompt_key_init == 'uniform':
                self.prompt_key_vecs = nn.Parameter(torch.randn(key_shape), requires_grad=False)
                nn.init.uniform_(self.prompt_key_vecs, -5, 5)
            elif prompt_key_init == 'gaussian':
                self.prompt_key_vecs = nn.Parameter(torch.randn(key_shape), requires_grad=False)
                nn.init.normal_(self.prompt_key_vecs, mean=0.0, std=5.0)
            elif prompt_key_init == 'text_prototype':
                self.text_prototype_linear = nn.Linear(50257, pool_size)
        else:
            # else use mean of prompt as key
            prompt_mean = torch.mean(self.prompt_pool_vecs, dim=1)
            self.prompt_key_vecs = prompt_mean

    def l2_normalize(self, x, dim=None, epsilon=1e-12):
        square_sum = torch.sum(x ** 2, dim=dim, keepdim=True)
        x_inv_norm = torch.rsqrt(torch.maximum(square_sum, torch.tensor(epsilon, device=x.device)))
        return x * x_inv_norm

    def get_prompt(self, x_embed_norm, prompt_norm):
        node_features = torch.cat([x_embed_norm, prompt_norm], dim=0)
        similarity = torch.matmul(node_features, node_features.transpose(-1, -2))
        threshold = 0.0
        adj_matrix = (similarity > threshold).float()
        edge_index = adj_matrix.nonzero(as_tuple=True)
        graph_data = Data(x=node_features, edge_index=torch.stack(edge_index, dim=0))

        # (确保 GNN 也在正确的 device 上)
        model = GNN(in_channels=node_features.shape[1], out_channels=768).to(similarity.device)
        output_features = model(graph_data)

        A_embeds = output_features[:x_embed_norm.shape[0]]
        B_embeds = output_features[x_embed_norm.shape[0]:]

        final_similarity = F.cosine_similarity(A_embeds.unsqueeze(1), B_embeds.unsqueeze(0), dim=2)
        _, nearest_indices = torch.topk(final_similarity, k=self.top_k, dim=1)
        return nearest_indices, final_similarity

    def forward(self, x_embed, prompt_mask=None, cls_features=None):
        out = dict()
        if self.prompt_key:
            if self.embedding_key == 'mean':
                x_embed_mean = torch.mean(x_embed, dim=1)
            # ... (省略其他 embedding_key 逻辑) ...
            else:
                x_embed_mean = torch.mean(x_embed, dim=1)  # 默认为 mean

            if self.prompt_key_init == 'text_prototype':
                prompt_key = self.wte.transpose(0, 1)
            else:
                prompt_key = self.prompt_key_vecs  # 使用修复后的变量

            prompt_norm = self.l2_normalize(prompt_key, dim=1)
            x_embed_norm = self.l2_normalize(x_embed_mean, dim=1)

            idx, final_similarity = self.get_prompt(x_embed_norm, prompt_norm)

            # (!!! 关键修复: 应该从 self.prompt_pool_vecs 中索引, 而不是 prompt_key)
            batched_prompt_raw = self.prompt_pool_vecs[idx]  # (B, top_k, length, C)
            batched_prompt_raw = batched_prompt_raw.unsqueeze(2)  # (B, top_k, 1, length, C) -> 这行似乎多余，原shape已正确

            # 修正：
            batched_prompt_raw = self.prompt_pool_vecs[idx]  # (B, top_k, length, C)
            batch_size, top_k, length, c = batched_prompt_raw.shape
            batched_prompt = batched_prompt_raw.reshape(batch_size, top_k * length, c)  # (B, top_k * length, C)

            out['prompt_idx'] = idx
            out['prompt_norm'] = prompt_norm
            out['x_embed_norm'] = x_embed_norm

            batched_key_norm = prompt_norm[idx]
            out['selected_key'] = batched_key_norm
            x_embed_norm = x_embed_norm.unsqueeze(1)
            sim = batched_key_norm * x_embed_norm
            reduce_sim = torch.sum(sim) / x_embed.shape[0]
            out['reduce_sim'] = reduce_sim
        else:
            # (省略非 prompt_key 的逻辑) ...
            pass

        out['total_prompt_len'] = batched_prompt.shape[1]
        out['prompted_embedding'] = torch.cat([batched_prompt, x_embed], dim=1)
        out['prompt_key'] = prompt_key
        return out
# --- 步骤 1 结束 ---