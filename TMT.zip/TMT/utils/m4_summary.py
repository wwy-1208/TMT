# This source code is provided for the purposes of scientific reproducibility
# under the following limited license from Element AI Inc. The code is an
# implementation of the N-BEATS model (Oreshkin et al., N-BEATS: Neural basis
# expansion analysis for interpretable time series forecasting,
# https://arxiv.org/abs/1905.10437). The copyright to the source code is
# licensed under the Creative Commons - Attribution-NonCommercial 4.0
# International license (CC BY-NC 4.0):
# https://creativecommons.org/licenses/by-nc/4.0/.  Any commercial use (whether
# for the benefit of third parties or internally in production) requires an
# explicit license. The subject-matter of the N-BEATS model and associated
# materials are the property of Element AI Inc. and may be subject to patent
# protection. No license to patents is granted hereunder (whether express or
# implied). Copyright 2020 Element AI Inc. All rights reserved.

"""
M4 Summary
"""
from collections import OrderedDict

import numpy as np
import pandas as pd

from data_provider.m4 import M4Dataset
from data_provider.m4 import M4Meta
import os


def group_values(values, groups, group_name):
    """
    修复：返回统一长度的数组（按M4对应group的horizon截断/填充）
    """
    # 1. 获取当前group的预测长度（horizon）
    horizon = M4Meta.horizons_map[group_name]
    # 2. 筛选当前group的序列
    group_vals = values[groups == group_name]
    # 3. 统一每个序列的长度到horizon
    unified_vals = []
    for v in group_vals:
        # 去掉NaN值
        v_clean = v[~np.isnan(v)]
        # 短则补0，长则截断到horizon
        if len(v_clean) < horizon:
            v_unified = np.pad(v_clean, (0, horizon - len(v_clean)), 'constant', constant_values=0.0)
        else:
            v_unified = v_clean[:horizon]
        unified_vals.append(v_unified)
    return np.array(unified_vals, dtype=np.float32)


def mase(forecast, insample, outsample, frequency):
    """修复：避免分母为0 + 限制极端值"""
    # 计算模型MAE（分子）
    model_mae = np.mean(np.abs(forecast - outsample))

    # 计算naive基准MAE（分母）- 多层容错
    if len(insample) <= max(1, frequency):
        # 情况1：insample长度不足 → 用简单差分
        naive_diff = insample[1:] - insample[:-1]
        naive_mae = np.mean(np.abs(naive_diff)) if len(naive_diff) > 0 else 1e-5
    else:
        # 情况2：正常计算季节性差分
        naive_diff = insample[:-frequency] - insample[frequency:]
        naive_mae = np.mean(np.abs(naive_diff))

    # 最终容错：若基准MAE为0，用极小值替代
    naive_mae = naive_mae if naive_mae != 0 else 1e-5

    # 计算MASE并限制最大值（避免极端值）
    mase_value = model_mae / naive_mae
    return min(mase_value, 100.0)  # 限制MASE最大为100


def smape_2(forecast, target):
    denom = np.abs(target) + np.abs(forecast)
    # divide by 1.0 instead of 0.0, in case when denom is zero the enumerator will be 0.0 anyway.
    denom[denom == 0.0] = 1.0
    return 200 * np.abs(forecast - target) / denom


def mape(forecast, target):
    denom = np.abs(target)
    # divide by 1.0 instead of 0.0, in case when denom is zero the enumerator will be 0.0 anyway.
    denom[denom == 0.0] = 1.0
    return 100 * np.abs(forecast - target) / denom


class M4Summary:
    def __init__(self, file_path, root_path):
        self.file_path = file_path
        self.training_set = M4Dataset.load(training=True, dataset_file=root_path)
        self.test_set = M4Dataset.load(training=False, dataset_file=root_path)
        self.naive_path = os.path.join(root_path, 'submission-Naive2.csv')

    def evaluate(self):
        """
        Evaluate forecasts using M4 test dataset.

        :return: sMAPE and OWA grouped by seasonal patterns.
        """
        grouped_owa = OrderedDict()

        # ========== 修复1：处理naive2_forecasts长度不均匀问题 ==========
        naive2_forecasts = pd.read_csv(self.naive_path).values[:, 1:].astype(np.float32)
        # 先按group拆分，再统一长度（避免直接转数组报错）
        naive2_forecasts_grouped = {}
        for group_name in M4Meta.seasonal_patterns:
            naive2_forecasts_grouped[group_name] = group_values(naive2_forecasts, self.test_set.groups, group_name)

        model_mases = {}
        naive2_smapes = {}
        naive2_mases = {}
        grouped_smapes = {}
        grouped_mapes = {}

        for group_name in M4Meta.seasonal_patterns:
            file_name = self.file_path + group_name + "_forecast.csv"
            if not os.path.exists(file_name):
                print(f"⚠️  跳过不存在的文件：{file_name}")
                continue  # 跳过不存在的子集，避免报错

            # ========== 修复2：加载并统一模型预测结果的长度 ==========
            model_forecast = pd.read_csv(file_name).values
            # 统一模型预测结果到当前group的horizon
            horizon = M4Meta.horizons_map[group_name]
            model_forecast_unified = []
            for v in model_forecast:
                v_clean = v[~np.isnan(v)] if len(v) > 0 else np.array([])
                if len(v_clean) < horizon:
                    v_unified = np.pad(v_clean, (0, horizon - len(v_clean)), 'constant', constant_values=0.0)
                else:
                    v_unified = v_clean[:horizon]
                model_forecast_unified.append(v_unified)
            model_forecast = np.array(model_forecast_unified, dtype=np.float32)

            # ========== 修复3：用统一长度的naive2预测结果 ==========
            naive2_forecast = naive2_forecasts_grouped[group_name]
            target = group_values(self.test_set.values, self.test_set.groups, group_name)
            # all timeseries within group have same frequency
            frequency = self.training_set.frequencies[self.test_set.groups == group_name][0]
            insample = group_values(self.training_set.values, self.test_set.groups, group_name)

            # ========== 修复4：确保所有数组长度匹配 ==========
            # 取最小长度（防止个别情况长度不匹配）
            min_len = min(len(model_forecast), len(naive2_forecast), len(target), len(insample))
            if min_len == 0:
                print(f"⚠️  {group_name}子集无有效数据，跳过")
                continue
            model_forecast = model_forecast[:min_len]
            naive2_forecast = naive2_forecast[:min_len]
            target = target[:min_len]
            insample = insample[:min_len]

            # 计算指标
            model_mases[group_name] = np.mean([mase(forecast=model_forecast[i],
                                                    insample=insample[i],
                                                    outsample=target[i],
                                                    frequency=frequency) for i in range(len(model_forecast))])
            naive2_mases[group_name] = np.mean([mase(forecast=naive2_forecast[i],
                                                     insample=insample[i],
                                                     outsample=target[i],
                                                     frequency=frequency) for i in range(len(model_forecast))])

            naive2_smapes[group_name] = np.mean(smape_2(naive2_forecast, target))
            grouped_smapes[group_name] = np.mean(smape_2(forecast=model_forecast, target=target))
            grouped_mapes[group_name] = np.mean(mape(forecast=model_forecast, target=target))

        # 仅对存在的group计算汇总
        if not grouped_smapes:
            print("⚠️  无有效子集数据，返回空指标")
            return {}, {}, {}, {}

        grouped_smapes = self.summarize_groups(grouped_smapes)
        grouped_mapes = self.summarize_groups(grouped_mapes)
        grouped_model_mases = self.summarize_groups(model_mases)
        grouped_naive2_smapes = self.summarize_groups(naive2_smapes)
        grouped_naive2_mases = self.summarize_groups(naive2_mases)

        # ========== 修复5：OWA计算容错（处理inf/nan） ==========
        for k in grouped_model_mases.keys():
            if k in grouped_naive2_mases and k in grouped_smapes and k in grouped_naive2_smapes:
                # 提取指标并处理异常值
                m_mase = grouped_model_mases[k]
                n2_mase = grouped_naive2_mases[k]
                m_smape = grouped_smapes[k]
                n2_smape = grouped_naive2_smapes[k]

                # 替换inf/nan为合理值
                m_mase = 100.0 if np.isinf(m_mase) or np.isnan(m_mase) else m_mase
                n2_mase = 1.0 if np.isinf(n2_mase) or np.isnan(n2_mase) or n2_mase == 0 else n2_mase
                m_smape = 100.0 if np.isinf(m_smape) or np.isnan(m_smape) else m_smape
                n2_smape = 1.0 if np.isinf(n2_smape) or np.isnan(n2_smape) or n2_smape == 0 else n2_smape

                # 计算OWA
                grouped_owa[k] = (m_mase / n2_mase + m_smape / n2_smape) / 2

        def round_all(d):
            return dict(map(lambda kv: (kv[0], np.round(kv[1], 3)), d.items()))

        return round_all(grouped_smapes), round_all(grouped_owa), round_all(grouped_mapes), round_all(
            grouped_model_mases)

    def summarize_groups(self, scores):
        """
        Re-group scores respecting M4 rules.
        :param scores: Scores per group.
        :return: Grouped scores.
        """
        scores_summary = OrderedDict()

        def group_count(group_name):
            return len(np.where(self.test_set.groups == group_name)[0])

        weighted_score = {}
        # 仅处理存在的group
        for g in ['Yearly', 'Quarterly', 'Monthly']:
            if g in scores:
                weighted_score[g] = scores[g] * group_count(g)
                scores_summary[g] = scores[g]

        others_score = 0
        others_count = 0
        for g in ['Weekly', 'Daily', 'Hourly']:
            if g in scores:
                others_score += scores[g] * group_count(g)
                others_count += group_count(g)
        if others_count > 0:
            weighted_score['Others'] = others_score
            scores_summary['Others'] = others_score / others_count

        # 计算平均值（仅对有数据的group）
        if weighted_score:
            average = np.sum(list(weighted_score.values())) / sum([group_count(g) for g in weighted_score.keys()])
            scores_summary['Average'] = average

        return scores_summary