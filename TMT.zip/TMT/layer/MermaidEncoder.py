import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from pytorch_wavelets import DWT1DForward, DWT1DInverse
from layer.Decomposition import Decomposition


class DiffAttention(nn.Module):
    def __init__(self, d_model, n_heads, mask_flag=False, scale=None, attention_dropout=0.1, output_attention=False,
                 lambda_init=0):
        super(DiffAttention, self).__init__()
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)
        d_keys = d_model // n_heads

        self.lambda_q1 = nn.Parameter(torch.randn(n_heads, d_keys))
        self.lambda_k1 = nn.Parameter(torch.randn(n_heads, d_keys))
        self.lambda_q2 = nn.Parameter(torch.randn(n_heads, d_keys))
        self.lambda_k2 = nn.Parameter(torch.randn(n_heads, d_keys))

        self.lambda_init = lambda_init
        self.rms_scale = nn.Parameter(torch.ones(2 * d_keys))
        self.eps = 1e-5

        self._reset_parameters()

    def _reset_parameters(self):
        nn.init.constant_(self.rms_scale, 1.0)

    def forward(self, queries, keys, values, attn_mask=None):
        # queries: [B, L, H, E]
        q1, q2 = queries.chunk(2, dim=-1)
        k1, k2 = keys.chunk(2, dim=-1)

        B, L, H, E = q1.shape
        _, S, _, D = values.shape
        scale = self.scale or 1. / math.sqrt(E)

        lambda_q1_dot_k1 = torch.sum(self.lambda_q1 * self.lambda_k1, dim=-1).float()
        lambda_q2_dot_k2 = torch.sum(self.lambda_q2 * self.lambda_k2, dim=-1).float()
        lambda_val = torch.exp(lambda_q1_dot_k1) - torch.exp(lambda_q2_dot_k2) + self.lambda_init
        lambda_val = lambda_val.unsqueeze(0).unsqueeze(-1).unsqueeze(-1)

        scores1 = torch.softmax(scale * torch.einsum("blhe,bshe->bhls", q1, k1), dim=-1)
        scores2 = torch.softmax(scale * torch.einsum("blhe,bshe->bhls", q2, k2), dim=-1)

        A = scores1 - lambda_val * scores2
        V = torch.einsum("bhls,bshd->bhld", A, values)

        O_reshaped = V.contiguous().view(B * H, L, -1)
        rms_norm = torch.sqrt(O_reshaped.pow(2).mean(dim=-1, keepdim=True) + self.eps)
        O_normalized = (O_reshaped / rms_norm) * self.rms_scale
        O_normalized = O_normalized * (1 - self.lambda_init)
        O_concat = O_normalized.contiguous().view(B, H, L, -1)

        O_final = O_concat.permute(0, 2, 1, 3).contiguous().view(B, L, -1)

        if self.output_attention:
            return (O_final, A)
        else:
            return (O_final, None)


class DiffTransformerLayer(nn.Module):
    def __init__(self, d_model, n_heads, d_keys=None, d_values=None, dropout=0.1):
        super(DiffTransformerLayer, self).__init__()

        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        self.inner_attention = DiffAttention(d_model, n_heads, mask_flag=False, attention_dropout=dropout)

        # 投影层
        self.query_projection = nn.Linear(d_model, 2 * d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, 2 * d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, 2 * d_values * n_heads)
        self.out_projection = nn.Linear(2 * d_values * n_heads, d_model)

        self.n_heads = n_heads
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(d_model)

    def forward(self, x):
        # x: [B, L, D]
        B, L, _ = x.shape
        H = self.n_heads

        queries = self.query_projection(x).view(B, L, H, -1)
        keys = self.key_projection(x).view(B, L, H, -1)
        values = self.value_projection(x).view(B, L, H, -1)

        out, _ = self.inner_attention(queries, keys, values)

        out = out.view(B, L, -1)
        out = self.out_projection(out)

        return self.norm(x + self.dropout(out))


class MermaidEncoder_Wavelet(nn.Module):
    def __init__(self, configs, device, word_embedding):
        super().__init__()
        self.configs = configs
        self.device = device
        self.d_model = configs.d_model


        self.student_projection = nn.Linear(configs.seq_len, configs.d_model)

        self.student_diff_attn = DiffTransformerLayer(
            d_model=configs.d_model,
            n_heads=configs.n_heads,
            dropout=configs.dropout
        )

        student_encoder_layer = nn.TransformerEncoderLayer(d_model=configs.d_model, nhead=configs.n_heads)
        self.student_transformer = nn.TransformerEncoder(student_encoder_layer, num_layers=configs.e_layers)

        self.dwt_module = Decomposition(
            input_length=configs.seq_len,
            pred_length=configs.pred_len,
            wavelet_name=getattr(configs, 'wavelet_name', 'db4'),
            level=getattr(configs, 'wavelet_level', 3),
            batch_size=configs.batch_size,
            channel=configs.enc_in,
            d_model=configs.d_model,
            device=device,
            no_decomposition=False,
            use_amp=configs.use_amp,
            tfactor=None,
            dfactor=None
        )

        total_wavelet_dim = sum(self.dwt_module.input_w_dim)
        self.teacher_wavelet_projection = nn.Linear(total_wavelet_dim, configs.d_model)

        self.word_embedding = word_embedding.T
        self.cross_attn_T2S = nn.MultiheadAttention(embed_dim=configs.d_model, num_heads=configs.n_heads)
        self.cross_attn_S2T = nn.MultiheadAttention(embed_dim=configs.d_model, num_heads=configs.n_heads)

    def forward(self, x):
        B, M, L = x.shape
        x_student = self.student_projection(x)

        x_student = self.student_diff_attn(x_student)

        x_student = x_student.transpose(0, 1)
        x_student = self.student_transformer(x_student)
        x_student = x_student.transpose(0, 1)  # 回到 (B, M, d)

        yl, yh = self.dwt_module.transform(x)
        wavelet_coeffs = [yl]
        wavelet_coeffs.extend(yh)
        x_wavelet_cat = torch.cat(wavelet_coeffs, dim=2)

        x_wavelet_proj = self.teacher_wavelet_projection(x_wavelet_cat)

        q_time = x_wavelet_proj.transpose(0, 1)  # (M, B, d)

        B_attn = q_time.shape[1]
        if self.word_embedding.ndim == 2:
            q_text = self.word_embedding.repeat(B_attn, 1, 1).transpose(0, 1)
        elif self.word_embedding.shape[0] != B_attn:
            q_text = self.word_embedding[0].repeat(B_attn, 1, 1).transpose(0, 1)
        else:
            q_text = self.word_embedding.transpose(0, 1)

        feat_T2S, _ = self.cross_attn_T2S(q_time, q_text, q_text)

        feat_S2T, _ = self.cross_attn_S2T(q_text, q_time, q_time)

        global_semantic_context = torch.mean(feat_S2T, dim=0, keepdim=True)
        x_teacher = feat_T2S + global_semantic_context
        x_teacher = x_teacher.transpose(0, 1)

        return x_student, x_teacher